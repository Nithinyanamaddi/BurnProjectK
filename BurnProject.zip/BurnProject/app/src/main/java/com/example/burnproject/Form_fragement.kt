package com.example.burnproject

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text
import java.sql.Time
import java.util.jar.Attributes.Name

// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER


/**
 * A simple [Fragment] subclass.
 * Use the [Form_fragement.newInstance] factory method to
 * create an instance of this fragment.
 */
class Form_fragement : Fragment() {
  lateinit var name: EditText
  lateinit var age: EditText
  lateinit var weight: EditText
  lateinit var time: EditText
  lateinit var cause: EditText
  lateinit var medical: EditText
  lateinit var result: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        }


    override fun onCreateView(
    inflater: LayoutInflater, container: ViewGroup?,
    savedInstanceState: Bundle?
): View? {
    // Inflate the layout for this fragment
    val view: View = inflater.inflate(R.layout.fragment_form_fragement,container,false)
        name=view.findViewById(R.id.Name)
        age=view.findViewById(R.id.Age)
        weight=view.findViewById(R.id.Weight)
        time=view.findViewById(R.id.Time)
        cause=view.findViewById(R.id.cause)
        medical=view.findViewById(R.id.medical)
        result=view.findViewById(R.id.result)

        result.setOnClickListener(View.OnClickListener {
            val name: String = name.text.toString()
            val age: String = age.text.toString()
            val weight:String= weight.text.toString()
            val time: String = time.text.toString()
            val cause: String = cause.text.toString()
            val medical: String = medical.text.toString()

            if(name.isEmpty() ||age.isEmpty()||weight.isEmpty()||time.isEmpty()){
                Toast.makeText(requireContext(),"Enter All details compulsary",Toast.LENGTH_SHORT).show()
            }
            if(!(age.toInt()>0&&age.toInt()<70)){
                Toast.makeText(requireContext(),"Enter Age correctly",Toast.LENGTH_SHORT).show()
            }
        })
        return view
    }
}


